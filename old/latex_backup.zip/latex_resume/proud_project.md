Describe a project you’re proud of where you helped build a scalable, complex application in a high-volume or high-traffic environment. What was the scale of the system (e.g., requests per second, users served, data volume)? What challenges did you face, and how did you overcome them? Please also share the tools and technologies you used.*


In Grab, I owned and designed two critical financial modules for Indonesia's BNPL product launch. serving 5M+ potential users during initial phase.
Refund API: The core challenge was managing complex error retries using state machine and creating the idempotent API that can scale and function correctly. Additionally there were integration with notification system from a new team that required event based communication compared to earlier sync API based communication. The system processed tens of thousands of refunds daily with zero data-loss incidents.

Service Fee Engine: the product requirement was complex, users were charged fixed initial fee based on their credit limit and only during the first transaction of the billing cycle. And the fee was also recomputed based on actual usage during bill generation. The challenge was managing the initial charge calculation in an idempotent manner. Handling retries for multiple dependent system calls and minimal refactors to the billing flow to accommodate the new change.

Tech: Go, PostgreSQL , REDIS, Kafka, Aerospike. 